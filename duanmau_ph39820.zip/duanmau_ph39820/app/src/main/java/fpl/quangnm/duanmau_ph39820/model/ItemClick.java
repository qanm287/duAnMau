package fpl.quangnm.duanmau_ph39820.model;

public interface ItemClick {
    void onClickLoaiSach(LoaiSach loaiSach);
}
